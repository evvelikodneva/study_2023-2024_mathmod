---
## Front matter
lang: ru-RU
title: Лабораторная работа №4
author:
  - Великоднева Е.В.
institute:
  - Российский университет дружбы народов, Москва, Россия
date: 3 марта 2024

## i18n babel
babel-lang: russian
babel-otherlangs: english

## Formatting pdf
toc: false
toc-title: Содержание
slide_level: 2
aspectratio: 169
section-titles: true
theme: metropolis
header-includes:
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
---

# Вводная часть

## Цели и задачи

- Создать фазовые портреты гармонического осциллятора для трёх случаев:

1. Колебания гармонического осциллятора без затуханий и без действий внешней
силы
2. Колебания гармонического осциллятора c затуханием и без действий внешней
силы
3. Колебания гармонического осциллятора c затуханием и под действием внешней
силы

## Материалы и методы

- Язык программирования `julia` для создания математических моделей
- Результирующие форматы
	- `jl` для файлов с кодом
	- `png` для графиков

# Создание графиков

## Решение дифференциальных уравнений на julia

using Plots

using DifferentialEquations

w = 6^(1/2)

g = 0

dt = 0.05

t = (0.0, 60.0)

x0 = [0.6, 1.6]

function f(t)

    sin(0*t)

end

function eq(x, u, p, t)

    x[1] = u[2]

    x[2] = -w * w * u[1] - g* u[2] - f(t)

    return x

end

prob_sde = ODEProblem(eq, x0, t)

sol = solve(prob_sde, dt=dt)

## График для первого случая

![](./image/plot55.png)

# Построение графика для второго случая:

g = 6

![](./image/plot56.png)

# Построение графика для третьего случая:
w = 12^(1/2)

function f(t)

    sin(6*t)

end

![](./image/plot56.png)

# Результаты

Решили уравнения для гармонического осциллятора и построили фазовые портреты для трёх случаев с заданными входными данными.